<!DOCTYPE html>
<html>

<head>
    <title>ESIC</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
<!-- navbar -->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../index.php">ESIC</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Requirements</a></li>
      <li><a href="#">Profile</a></li>
      <li><a href="#">Contributions</a></li>
      <li><a href="#">Logout</a></li>
    </ul>
  </div>
</nav>
 <!-- navbar end -->
 <br><br>
 <div class="container jumbotron">
     <h2 style="text-align: center">Recent requirements in various hospitals.</h2>
     <br>
     <table class="table table-striped">
         <thead>
             <tr>
                 <th>req. date</th>
                 <th>discription</th>
                 <th>post</th>
                 <th>hospital</th>
                 <th>location</th>
             </tr>
         </thead>
         <tbody>
             <tr>
                 <td>20/02/2019 - 28/02/2019</td>
                 <td>Something</td>
                 <td>Doctor</td>
                 <td>Some place</td>
                 <td>Some place</td>
             </tr>
             <tr>
                 <td>20/02/2019 - 28/02/2019</td>
                 <td>Something</td>
                 <td>Intern</td>
                 <td>Some place</td>
                 <td>Some place</td>
             </tr>
         </tbody>
     </table>
 </div>
</body>

</html>
